let ghosts = [];


function setup() {
  createCanvas(500, 500);
  
 
  for (var i = 0; i < 10; i++) {
    ghosts.push(new Ghost());
  }

  noStroke();
}

function draw() {
  background(32);
  
  // text 
  if(mouseX > 50){
  textSize(50)
  fill("orange");
  text("HAPPY HALLOWEEN:", 0, 80);
  
  }
  
  for (const ghost of ghosts) {
    ghost.moveAndDraw();
  }
}


class Ghost {

  constructor() {

    this.tail = [];
    this.tailLength = 30;

  
    this.ghostSize = random(10, 100);
    this.ghostX = random(width);
    this.ghostY = random(height);

    
    this.cosOffset = random(100);
    this.wiggliness = random(2, 10);
    this.floatiness = random(2, 10);


    
    this.r = random(255);
    this.g = random(255);
    this.b = random(255);
  }

  moveAndDraw() {

    // Move ghost left and right.
    this.ghostX += cos((this.cosOffset + frameCount) / 10) * this.wiggliness;
    // Move the ghost up.
    this.ghostY -= this.floatiness;
    // Restart Ghost from bottom 
    if (this.ghostY < -this.ghostSize) {
      this.ghostY = height + this.ghostSize;
    }

    // Add a point 
    this.tail.unshift({x: this.ghostX, y: this.ghostY});
    if (this.tail.length > this.tailLength) {
      this.tail.pop();
    }


    // Loop over the tail 
    for (let index = 0; index < this.tail.length; index++) {
      const tailPoint = this.tail[index];

      // Tail gets smaller 
      const pointSize = this.ghostSize * (this.tail.length - index) / this.tail.length;
      const pointAlpha = 255 * (this.tail.length - index) / this.tail.length;

      fill(this.r, this.g, this.b, pointAlpha);
      ellipse(tailPoint.x, tailPoint.y, pointSize);
    }

    // ghost's face. O_O
    fill(32);
    ellipse(this.ghostX - this.ghostSize * .2,
            this.ghostY - this.ghostSize * .1,
            this.ghostSize * .2);
    ellipse(this.ghostX + this.ghostSize * .2,
            this.ghostY - this.ghostSize * .1,
            this.ghostSize * .2);
    ellipse(this.ghostX,
            this.ghostY + this.ghostSize * .2,
            this.ghostSize * .2);
    
  // Pumpkin 
    
    // stem
  stroke(0, 160, 0);
  strokeWeight(20);
  line(250, 150, 225, 100);

  // orange
  fill(255, 100, 0);
  stroke(120, 60, 0);
  strokeWeight(3);

  // pumpkin circles
  ellipse(250, 250, 400, 200);
  ellipse(250, 250, 300, 200);
  ellipse(250, 250, 200, 200);
  ellipse(250, 250, 100, 200);

  fill(0);
  noStroke();

  // eyes
  triangle(
    175, 200,
    150, 225,
    200, 225);
  triangle(
    325, 200,
    300, 225,
    350, 225);

  // mouth
  arc(
    250, 275,
    250, 75,
    radians(0), radians(180));
  }
}